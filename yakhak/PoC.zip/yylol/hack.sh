#!/bin/sh

if [ $# -ne 2 ]
    then
        echo "Usage: ./hack.sh <your phone's IP address> <userID to hack>"
    else
        PHONE_IP=$1
        USER=$2
        ssh root@$PHONE_IP yylol $USER
        echo "User spoofed!"
        echo "Restart your phone and run the YY app! Have fun :)"
fi
