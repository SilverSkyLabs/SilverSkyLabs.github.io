#/bin/sh

sudo tshark -i en0 -I -w data/yylol.pcap
