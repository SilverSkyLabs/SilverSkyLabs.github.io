#!/bin/sh

if [ $# -eq 0 ]
    then
        echo "Usage: ./install.sh <your phone's IP address>"
    else
        PHONE_IP=$1
        scp yylol root@$PHONE_IP:/usr/bin/
        ssh root@$PHONE_IP chmod +x /usr/bin/yylol
        echo "Installed!"
        echo "Run from ssh or phone's terminal: yylol <userID to hack>"
fi
