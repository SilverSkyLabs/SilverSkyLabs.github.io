#/bin/sh

if [ $# -ne 1 ]
    then
        echo "Usage: ./spy.sh <userID>"
    else
        USER=$1
        echo "Getting posts for user: $1"
        echo
        curl -sS "https://us-east-api.yikyakapi.net/api/getMyRecentYaks?userID=$1" | sed -e 's/[{}]/''/g' | awk -v k="text" '{n=split($0,a,","); for (i=1; i<=n; i++) print a[i]}' | grep '"message":'
        echo
fi
